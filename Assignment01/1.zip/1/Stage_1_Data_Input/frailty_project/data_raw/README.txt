README.txt

Metadata file for frailty data

Frailty:
	N = no
	Y = Yes

Height: inches
Weight: pounds
Age: years
Grip Strength: kilograms